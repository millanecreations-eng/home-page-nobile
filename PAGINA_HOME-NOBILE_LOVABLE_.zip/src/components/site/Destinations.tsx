import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import rio from "@/assets/dest-rio.jpg";
import sp from "@/assets/dest-sp.jpg";
import parana from "@/assets/dest-parana.jpg";
import chile from "@/assets/dest-chile.jpg";
import orlando from "@/assets/dest-orlando.jpg";
import paraguai from "@/assets/dest-paraguai.jpg";

const destinations = [
  { name: "Rio de Janeiro", country: "Brasil", hotels: 2, img: rio, slug: "rio-de-janeiro" },
  { name: "São Paulo", country: "Brasil", hotels: 7, img: sp, slug: "sao-paulo" },
  { name: "Paraná", country: "Brasil", hotels: 8, img: parana, slug: "parana" },
  { name: "Chile", country: "Chile", hotels: 3, img: chile, slug: "chile" },
  { name: "Orlando", country: "Estados Unidos", hotels: 1, img: orlando, slug: "orlando" },
  { name: "Paraguai", country: "Paraguai", hotels: 5, img: paraguai, slug: "paraguai" },
];

const Destinations = () => {
  return (
    <section id="destinos" className="py-12 md:py-16">
      <div className="container-page">
        <div className="flex items-end justify-between mb-6 gap-4 flex-wrap">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold text-foreground tracking-tight">
              Destinos em alta
            </h2>
            <p className="text-muted-foreground mt-1">
              Os lugares mais procurados pelos nossos hóspedes
            </p>
          </div>
          <Link
            to="/hoteis"
            className="text-accent font-semibold hover:underline inline-flex items-center gap-1 text-sm"
          >
            Ver todos os destinos
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        {/* Mobile: horizontal scroll · Desktop: grid */}
        <div className="flex gap-4 overflow-x-auto md:grid md:grid-cols-3 md:gap-5 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:px-0 scrollbar-hide pb-2">
          {destinations.map((d) => (
            <Link
              key={d.name}
              to={`/hoteis?dest=${encodeURIComponent(d.name + ", " + d.country)}`}
              className="group relative overflow-hidden rounded-2xl shadow-card hover:shadow-card-hover transition-all aspect-[3/4] md:aspect-[4/3] shrink-0 w-[260px] md:w-auto"
            >
              <img
                src={d.img}
                alt={`Hotéis em ${d.name}, ${d.country}`}
                width={800}
                height={1000}
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5 text-primary-foreground">
                <h3 className="text-xl md:text-2xl font-bold">{d.name}</h3>
                <p className="text-sm text-primary-foreground/85 mt-0.5">
                  {d.country} · {d.hotels} hotéis
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Destinations;
