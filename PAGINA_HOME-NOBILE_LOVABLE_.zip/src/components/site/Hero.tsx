import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Sparkles } from "lucide-react";
import type { DateRange } from "react-day-picker";
import heroImg from "@/assets/hero-hotel.jpg";
import DestinationCombobox from "./search/DestinationCombobox";
import DateRangePicker from "./search/DateRangePicker";
import GuestsPopover, { type Guests } from "./search/GuestsPopover";

const Hero = () => {
  const navigate = useNavigate();
  const [destination, setDestination] = useState("");
  const [dates, setDates] = useState<DateRange | undefined>();
  const [guests, setGuests] = useState<Guests>({ adults: 2, children: 0, rooms: 1 });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (destination) params.set("dest", destination);
    if (dates?.from) params.set("from", dates.from.toISOString().slice(0, 10));
    if (dates?.to) params.set("to", dates.to.toISOString().slice(0, 10));
    params.set("adults", String(guests.adults));
    params.set("children", String(guests.children));
    params.set("rooms", String(guests.rooms));
    navigate(`/hoteis?${params.toString()}`);
  };

  return (
    <section className="relative bg-primary">
      <div className="absolute inset-0">
        <img
          src={heroImg}
          alt="Hotel beira-mar da rede Nobile Hotels & Resorts ao pôr do sol"
          width={1920}
          height={1080}
          className="h-full w-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
      </div>

      <div className="container-page relative pt-12 pb-32 md:pt-24 md:pb-40 text-primary-foreground">
        <div className="max-w-3xl animate-fade-in">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 mb-4 text-xs font-semibold rounded-full bg-highlight text-highlight-foreground">
            <Sparkles className="h-3.5 w-3.5" />
            63 hotéis · Brasil & Internacional
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.05] tracking-tight">
            Encontre sua próxima estadia
          </h1>
          <p className="mt-4 text-lg md:text-xl text-primary-foreground/90 max-w-2xl">
            Reserve em hotéis exclusivos da rede Nobile Hotels & Resorts — presente no Brasil, América Latina, Estados Unidos e Portugal.
          </p>
        </div>
      </div>

      {/* Search bar — clean & minimal */}
      <div className="container-page relative -mt-16 md:-mt-20 z-10">
        <form
          className="bg-card rounded-2xl p-2 shadow-search grid grid-cols-1 md:grid-cols-[1.4fr_1.6fr_1fr_auto] gap-1 border"
          onSubmit={handleSearch}
        >
          <DestinationCombobox value={destination} onChange={setDestination} />
          <DateRangePicker value={dates} onChange={setDates} />
          <GuestsPopover value={guests} onChange={setGuests} />
          <button
            type="submit"
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-accent text-accent-foreground font-semibold hover:bg-accent-hover transition-colors"
          >
            <Search className="h-5 w-5" />
            Buscar
          </button>
        </form>
      </div>
    </section>
  );
};

export default Hero;
